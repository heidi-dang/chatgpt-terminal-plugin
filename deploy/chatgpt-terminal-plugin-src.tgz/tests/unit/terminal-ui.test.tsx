// @vitest-environment jsdom
import { join } from 'node:path';
import React, { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  app: {
    ontoolresult: undefined as ((result: unknown) => Promise<void>) | undefined,
    onhostcontextchanged: undefined as ((context: Record<string, unknown>) => void) | undefined,
    onteardown: undefined as (() => Promise<unknown>) | undefined,
    onerror: undefined as ((error: Error) => void) | undefined,
    getHostContext: vi.fn(() => ({ theme: 'dark', platform: 'mobile' })),
    callServerTool: vi.fn(),
  },
  refreshCount: 0,
  terminals: [] as Array<{
    options: Record<string, unknown>;
    writes: string[];
    clear: ReturnType<typeof vi.fn>;
    dispose: ReturnType<typeof vi.fn>;
    getSelection: ReturnType<typeof vi.fn>;
    cols: number;
    rows: number;
  }>,
}));

vi.mock('@modelcontextprotocol/ext-apps/react', async () => {
  const React = await import('react');
  return {
    useApp: (options: { onAppCreated?: (app: unknown) => void }) => {
      React.useEffect(() => {
        options.onAppCreated?.(mocks.app);
      }, []);
      return { app: mocks.app, error: null, isConnected: true };
    },
    useHostStyles: () => undefined,
  };
});

vi.mock('@xterm/xterm', () => ({
  Terminal: class FakeTerminal {
    options: Record<string, unknown>;
    writes: string[] = [];
    clear = vi.fn();
    dispose = vi.fn();
    getSelection = vi.fn(() => 'selected text');
    cols = 80;
    rows = 24;
    constructor(options: Record<string, unknown>) {
      this.options = options;
      mocks.terminals.push(this);
    }
    loadAddon() {}
    open() {}
    write(text: string) { this.writes.push(text); }
  },
}));

vi.mock('@xterm/addon-fit', () => ({
  FitAddon: class FakeFitAddon { fit() {} },
}));

class FakeResizeObserver {
  static instances: FakeResizeObserver[] = [];
  constructor(private readonly callback: ResizeObserverCallback) {
    FakeResizeObserver.instances.push(this);
  }
  observe() {}
  disconnect() {}
  trigger(): void {
    this.callback([], this as unknown as ResizeObserver);
  }
}

class FakeEventSource {
  static instances: FakeEventSource[] = [];
  onopen: (() => void) | null = null;
  onerror: (() => void) | null = null;
  onmessage: ((event: MessageEvent<string>) => void) | null = null;
  close = vi.fn();
  constructor(readonly url: string) {
    FakeEventSource.instances.push(this);
  }
  emit(data: unknown): void {
    this.onmessage?.({ data: JSON.stringify(data) } as MessageEvent<string>);
  }
  emitError(): void {
    this.onerror?.();
  }
  emitOpen(): void {
    this.onopen?.();
  }
}

let root: Root | undefined;

beforeEach(() => {
  globalThis.IS_REACT_ACT_ENVIRONMENT = true;
  document.body.innerHTML = '<div id="mount"></div>'; 
  mocks.terminals.length = 0;
  mocks.refreshCount = 0;
  FakeEventSource.instances.length = 0;
  FakeResizeObserver.instances.length = 0;
  mocks.app.ontoolresult = undefined;
  mocks.app.onhostcontextchanged = undefined;
  mocks.app.onteardown = undefined;
  mocks.app.onerror = undefined;
  mocks.app.getHostContext.mockReturnValue({ theme: 'dark', platform: 'mobile' });
  mocks.app.callServerTool.mockReset();
  mocks.app.callServerTool.mockImplementation(async ({ name }: { name: string }) => {
    if (name === 'terminal_stream_refresh') {
      mocks.refreshCount += 1;
      return {
        structuredContent: { session_id: 'session-1', expires_at: new Date(Date.now() + 60_000).toISOString() },
        content: [],
        _meta: { terminal_stream: { url: `https://terminal.example/events?token=refreshed-${mocks.refreshCount}`, expires_at: new Date(Date.now() + 60_000).toISOString() } },
      };
    }
    if (name === 'terminal_status') {
      return { structuredContent: { session_id: 'session-1', status: 'running', cursor: 8, shell: 'bash', cwd: '/workspace' }, content: [] };
    }
    return { structuredContent: { session_id: 'session-1', status: 'running', cursor: 8 }, content: [] };
  });
  vi.stubGlobal('ResizeObserver', FakeResizeObserver);
  vi.stubGlobal('EventSource', FakeEventSource);
});

afterEach(async () => {
  if (root) {
    await act(async () => root?.unmount());
    root = undefined;
  }
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe('terminal MCP App UI', () => {
  it('renders session state, streams output, changes theme in place, interrupts, reconnects, and marks exit', async () => {
    const { TerminalApp } = await import('../../packages/terminal-ui/src/main.js');
    root = createRoot(document.getElementById('mount')!);
    await act(async () => root?.render(<TerminalApp />));
    expect(mocks.terminals).toHaveLength(1);
    const terminal = mocks.terminals[0]!;
    expect((terminal.options.theme as Record<string, string>).foreground).toBe('#e6edf3');

    await act(async () => {
      await mocks.app.ontoolresult?.({
        structuredContent: {
          session_id: 'session-1',
          agent_id: 'agent-1',
          agent_name: 'My computer',
          cwd: '/workspace',
          shell: 'bash',
          status: 'running',
          cursor: 4,
          initial_output: 'initial\r\n',
          exit_code: null,
        },
        content: [],
        _meta: {
          terminal_stream: {
            url: 'https://terminal.example/events?token=initial',
            expires_at: new Date(Date.now() + 60_000).toISOString(),
          },
        },
      });
    });

    expect(document.body.textContent).toContain('My computer');
    expect(document.body.textContent).toContain('/workspace');
    expect(terminal.writes).toContain('initial\r\n');
    expect(FakeEventSource.instances.at(-1)?.url).toContain('token=initial');

    await act(async () => {
      FakeEventSource.instances.at(-1)?.emit({ sequence: 5, event_type: 'terminal.stdout', data: { text: 'hello\r\n' } });
    });
    expect(terminal.writes).toContain('hello\r\n');

    await act(async () => {
      mocks.app.onhostcontextchanged?.({ theme: 'light' });
    });
    expect(mocks.terminals).toHaveLength(1);
    expect((terminal.options.theme as Record<string, string>).foreground).toBe('#1f2328');

    const interrupt = [...document.querySelectorAll('button')].find((button) => button.textContent === 'Ctrl+C')!;
    await act(async () => interrupt.click());
    expect(mocks.app.callServerTool).toHaveBeenCalledWith({
      name: 'terminal_interrupt',
      arguments: { session_id: 'session-1' },
    });
    expect(document.body.textContent).toContain('My computer');
    expect(document.body.textContent).toContain('/workspace');
    expect(document.querySelector('.terminal-footer')?.textContent).toContain('bash');

    const reconnect = [...document.querySelectorAll('button')].find((button) => button.textContent === 'Reconnect')!;
    await act(async () => reconnect.click());
    expect(mocks.app.callServerTool).toHaveBeenCalledWith({
      name: 'terminal_stream_refresh',
      arguments: { session_id: 'session-1', after: 5 },
    });

    const exitingSource = FakeEventSource.instances.at(-1)!;
    await act(async () => {
      exitingSource.emit({ sequence: 6, event_type: 'process.exit', data: { exit_code: 130 } });
    });
    expect(document.querySelector('.terminal-footer')?.textContent).toContain('offline');
    expect(document.querySelector('.terminal-footer')?.textContent).toContain('exit 130');
    expect(document.querySelector('.terminal-state')?.textContent).toContain('exited');
    expect(exitingSource.close).toHaveBeenCalled();
  });

  it('deduplicates SSE events, detects gaps, refreshes capabilities, and ignores stale sources', async () => {
    const { TerminalApp, classifySequence } = await import('../../packages/terminal-ui/src/main.js');
    expect(classifySequence(5, 5)).toBe('stale');
    expect(classifySequence(5, 6)).toBe('next');
    expect(classifySequence(5, 7)).toBe('gap');
    expect(classifySequence(5, Number.NaN)).toBe('gap');

    root = createRoot(document.getElementById('mount')!);
    await act(async () => root?.render(<TerminalApp />));
    await act(async () => {
      await mocks.app.ontoolresult?.({
        structuredContent: { session_id: 'session-1', agent_name: 'My computer', cwd: '/workspace', shell: 'bash', status: 'running', cursor: 4, initial_output: '' },
        content: [],
        _meta: { terminal_stream: { url: 'https://terminal.example/events?token=initial', expires_at: new Date(Date.now() + 60_000).toISOString() } },
      });
    });
    const terminal = mocks.terminals[0]!;
    const initialSource = FakeEventSource.instances.at(-1)!;

    await act(async () => initialSource.emit({ sequence: 5, event_type: 'terminal.stdout', data: { text: 'once\r\n' } }));
    await act(async () => initialSource.emit({ sequence: 5, event_type: 'terminal.stdout', data: { text: 'duplicate\r\n' } }));
    expect(terminal.writes).toContain('once\r\n');
    expect(terminal.writes).not.toContain('duplicate\r\n');

    await act(async () => {
      initialSource.emit({ sequence: 7, event_type: 'terminal.stdout', data: { text: 'gap\r\n' } });
      await Promise.resolve();
    });
    expect(initialSource.close).toHaveBeenCalled();
    expect(mocks.app.callServerTool).toHaveBeenCalledWith({
      name: 'terminal_stream_refresh',
      arguments: { session_id: 'session-1', after: 5 },
    });
    const recoveredSource = FakeEventSource.instances.at(-1)!;
    expect(recoveredSource).not.toBe(initialSource);
    expect(recoveredSource.url).toContain('refreshed-1');

    await act(async () => initialSource.emit({ sequence: 6, event_type: 'terminal.stdout', data: { text: 'stale-source\r\n' } }));
    expect(terminal.writes).not.toContain('stale-source\r\n');
    await act(async () => recoveredSource.emit({ sequence: 6, event_type: 'terminal.stdout', data: { text: 'recovered\r\n' } }));
    expect(terminal.writes).toContain('recovered\r\n');

    await act(async () => {
      recoveredSource.emitError();
      await Promise.resolve();
    });
    expect(recoveredSource.close).toHaveBeenCalled();
    expect(mocks.app.callServerTool).toHaveBeenCalledWith({
      name: 'terminal_stream_refresh',
      arguments: { session_id: 'session-1', after: 6 },
    });
    expect(FakeEventSource.instances.at(-1)?.url).toContain('refreshed-2');
  });

  it('debounces iframe resize traffic and stops resize mutations after terminal exit', async () => {
    vi.useFakeTimers();
    const { TerminalApp } = await import('../../packages/terminal-ui/src/main.js');
    root = createRoot(document.getElementById('mount')!);
    await act(async () => root?.render(<TerminalApp />));
    await act(async () => {
      await mocks.app.ontoolresult?.({
        structuredContent: { session_id: 'session-1', status: 'running', cursor: 4, shell: 'bash' },
        content: [],
        _meta: { terminal_stream: { url: 'https://terminal.example/events?token=initial', expires_at: new Date(Date.now() + 60_000).toISOString() } },
      });
    });
    const observer = FakeResizeObserver.instances.at(-1)!;
    observer.trigger();
    observer.trigger();
    await act(async () => vi.advanceTimersByTime(100));
    const resizeCalls = mocks.app.callServerTool.mock.calls.filter(([request]) => request.name === 'terminal_resize');
    expect(resizeCalls).toHaveLength(1);

    observer.trigger();
    await act(async () => vi.advanceTimersByTime(100));
    expect(mocks.app.callServerTool.mock.calls.filter(([request]) => request.name === 'terminal_resize')).toHaveLength(1);

    const source = FakeEventSource.instances.at(-1)!;
    await act(async () => source.emit({ sequence: 5, event_type: 'process.exit', data: { exit_code: 0 } }));
    mocks.terminals[0]!.cols = 100;
    observer.trigger();
    await act(async () => vi.advanceTimersByTime(100));
    expect(mocks.app.callServerTool.mock.calls.filter(([request]) => request.name === 'terminal_resize')).toHaveLength(1);
  });

  it('contains a compact mobile breakpoint for the ChatGPT iframe', async () => {
    const css = await import('node:fs/promises').then(({ readFile }) => readFile(
      join(process.cwd(), 'packages/terminal-ui/src/styles.css'),
      'utf8',
    ));
    expect(css).toMatch(/@media\s*\(max-width:\s*560px\)/);
    expect(css).toMatch(/terminal-toolbar/);
  });
});
